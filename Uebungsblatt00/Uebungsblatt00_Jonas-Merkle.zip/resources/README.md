# resources

This folder containers additional resources (e.g. images) for this assignment.
