# src

This folder containers the source code for this assignment.

## CAUTION

**Due to unclear licensing & publishing terms there are some crucial files missing in this repository.**
These files must be downloaded for the [moodle page of this course](https://moodle.uni-ulm.de/mod/assign/view.php?id=797791).

### Setup

to setup the project place the downloaded files & directories as follows:

- `javadoc.zip`:
    1. Unzip
    2. Move the `doc` directory to [./LunarLander_Tests/](./LunarLander_Tests/)
- `src.zip`
    1. Unzip
    2. Move the `src/LunarLander/TestLander.java` file to [./LunarLander_Tests/src/LunarLander/](./LunarLander_Tests/src/LunarLander/)
- `LunarLander_Mutants.jar`
    1. Move the `LunarLander_Mutants.jar` file to [./LunarLander_Tests/](./LunarLander_Tests/)
